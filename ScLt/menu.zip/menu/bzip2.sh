#!/bin/bash

BlueCyan="\033[5;36m"
YellowBe="\033[93;1m"
RedBe="\033[91;1m"
Cyan="\033[96;1m"
GreenBe="\033[5;32m"
Suffix="\033[0m"
clear
echo -e "${BlueCyan} ┌─────────────────────────────────────────────────┐${Suffix}"
echo -e "${YellowBe}                 LUNATIC TUNNELING        ${Suffix}"
echo -e "${BlueCyan} └─────────────────────────────────────────────────┘${Suffix}"
echo ""
echo "" 
echo -e "${GreenBe}                  DECRYPTER BZIP2         ${Suffix} "
echo ""
echo ""
echo -e "${RedBe} Input file enc = Masukan Nama file Encrypt ${Suffix}"
echo ""
echo -e "${RedBe} Input file dec = Masukan Nama file Hasil Decrypt ${Suffix}"
echo ""
echo ""
echo ""
# Nama file terenkripsi
read -p "input file enc   :  " nama_file_terenkripsi

# Mengecek apakah file terenkripsi ada
if [ ! -f "$nama_file_terenkripsi" ]; then
    echo "File terenkripsi tidak ditemukan."
    exit 1
fi

# Mendekripsi dan menyimpan hasilnya
read -p "Input Hasil Dec   :  " hasil_file
tail -n +23 "$nama_file_terenkripsi" | bzip2 -cd > "$hasil_file"
echo ""
echo ""
# Memberi izin eksekusi pada file hasil jika diperlukan
echo -e "${GreenBe} Succesfully ${Suffix}"
echo ""
echo ""
echo "Proses dekripsi selesai. Hasil disimpan di: $hasil_file"
